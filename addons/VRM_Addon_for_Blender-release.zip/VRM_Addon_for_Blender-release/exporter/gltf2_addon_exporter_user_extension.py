class Gltf2AddonExporterUserExtension:
    pass
